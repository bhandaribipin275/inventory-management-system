from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Sum, Count
from django.db.models.functions import TruncDate
from django.utils import timezone
from datetime import timedelta

from inventory.models import Stock, Category, Supplier, StockHistory
from transactions.models import Purchase, Sale, PurchaseItem, SaleItem


def register_view(request):
    """Handle user registration."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        email = request.POST.get('email', '').strip().lower()
        password1 = request.POST.get('password1', '')
        password2 = request.POST.get('password2', '')
        
        # Validation
        if not all([first_name, last_name, email, password1, password2]):
            messages.error(request, 'All fields are required.')
            return render(request, 'homepage/register.html')
        
        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'homepage/register.html')
        
        if len(password1) < 6:
            messages.error(request, 'Password must be at least 6 characters long.')
            return render(request, 'homepage/register.html')
        
        # Check if user already exists
        if User.objects.filter(username=email).exists():
            messages.error(request, 'This email is already registered.')
            return render(request, 'homepage/register.html')
        
        # Create user
        try:
            user = User.objects.create_user(
                username=email,
                email=email,
                password=password1,
                first_name=first_name,
                last_name=last_name
            )
            messages.success(request, 'Account created successfully! Please login.')
            return redirect('login')
        except Exception as e:
            messages.error(request, f'Error creating account: {str(e)}')
    
    return render(request, 'homepage/register.html')


def login_view(request):
    """Handle user login."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        
        # Try to authenticate with email as username
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {user.first_name or user.username}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid email or password.')
    
    return render(request, 'homepage/login.html')


def logout_view(request):
    """Handle user logout."""
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('login')


@login_required
def dashboard(request):
    """Main dashboard view with statistics and charts."""
    # Get date ranges
    today = timezone.now().date()
    week_ago = today - timedelta(days=7)
    month_ago = today - timedelta(days=30)
    
    # Stock statistics
    total_items = Stock.objects.count()
    low_stock_items = Stock.objects.filter(quantity__lte=10).count()
    out_of_stock = Stock.objects.filter(quantity=0).count()
    total_stock_value = Stock.objects.aggregate(
        total=Sum('quantity')
    )['total'] or 0
    
    # Category statistics
    total_categories = Category.objects.count()
    
    # Supplier statistics
    total_suppliers = Supplier.objects.count()
    
    # Transaction statistics
    total_purchases = Purchase.objects.count()
    total_sales = Sale.objects.count()
    
    # Recent transactions
    recent_purchases = Purchase.objects.order_by('-date')[:5]
    recent_sales = Sale.objects.order_by('-date')[:5]
    
    # Stock history for chart
    stock_history = StockHistory.objects.filter(
        created_at__date__gte=week_ago
    ).annotate(
        date=TruncDate('created_at')
    ).values('date', 'direction').annotate(
        count=Count('id')
    ).order_by('date')
    
    # Prepare chart data
    dates = []
    stock_in_data = []
    stock_out_data = []
    
    for i in range(7):
        date = week_ago + timedelta(days=i)
        dates.append(date.strftime('%b %d'))
        
        in_count = 0
        out_count = 0
        for entry in stock_history:
            if entry['date'] == date:
                if entry['direction'] == 'IN':
                    in_count = entry['count']
                else:
                    out_count = entry['count']
        
        stock_in_data.append(in_count)
        stock_out_data.append(out_count)
    
    # Low stock items list
    low_stock_list = Stock.objects.filter(quantity__lte=10).order_by('quantity')[:10]
    
    # Recent activity
    recent_history = StockHistory.objects.select_related('stock').order_by('-created_at')[:10]
    
    context = {
        'total_items': total_items,
        'low_stock_items': low_stock_items,
        'out_of_stock': out_of_stock,
        'total_stock_value': total_stock_value,
        'total_categories': total_categories,
        'total_suppliers': total_suppliers,
        'total_purchases': total_purchases,
        'total_sales': total_sales,
        'recent_purchases': recent_purchases,
        'recent_sales': recent_sales,
        'dates': dates,
        'stock_in_data': stock_in_data,
        'stock_out_data': stock_out_data,
        'low_stock_list': low_stock_list,
        'recent_history': recent_history,
    }
    
    return render(request, 'homepage/dashboard.html', context)


@login_required
def profile(request):
    """User profile view."""
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name', '')
        user.last_name = request.POST.get('last_name', '')
        user.email = request.POST.get('email', '')
        user.save()
        
        messages.success(request, 'Profile updated successfully!')
        return redirect('profile')
    
    return render(request, 'homepage/profile.html')
