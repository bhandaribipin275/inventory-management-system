from django.urls import path
from . import views

urlpatterns = [
    # Stock URLs
    path('', views.stock_list, name='stock_list'),
    path('add/', views.stock_add, name='stock_add'),
    path('<int:pk>/', views.stock_detail, name='stock_detail'),
    path('<int:pk>/edit/', views.stock_edit, name='stock_edit'),
    path('<int:pk>/delete/', views.stock_delete, name='stock_delete'),
    path('<int:pk>/adjust/', views.stock_adjust, name='stock_adjust'),
    
    # Category URLs
    path('categories/', views.category_list, name='category_list'),
    path('categories/add/', views.category_add, name='category_add'),
    path('categories/<int:pk>/edit/', views.category_edit, name='category_edit'),
    path('categories/<int:pk>/delete/', views.category_delete, name='category_delete'),
    
    # Supplier URLs
    path('suppliers/', views.supplier_list, name='supplier_list'),
    path('suppliers/add/', views.supplier_add, name='supplier_add'),
    path('suppliers/<int:pk>/edit/', views.supplier_edit, name='supplier_edit'),
    path('suppliers/<int:pk>/delete/', views.supplier_delete, name='supplier_delete'),
    
    # Stock History URL
    path('history/', views.stock_history, name='stock_history'),
]
