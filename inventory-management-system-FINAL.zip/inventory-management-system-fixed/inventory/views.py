from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator

from .models import Stock, Category, Supplier, StockHistory


# =============================================================================
# STOCK VIEWS
# =============================================================================

@login_required
def stock_list(request):
    """List all stock items with search and filter."""
    stocks = Stock.objects.select_related('category', 'supplier').all()
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        stocks = stocks.filter(
            Q(name__icontains=search_query) |
            Q(sku__icontains=search_query) |
            Q(description__icontains=search_query)
        )
    
    # Filter by category
    category_id = request.GET.get('category', '')
    if category_id:
        stocks = stocks.filter(category_id=category_id)
    
    # Filter by stock status
    status = request.GET.get('status', '')
    if status == 'low':
        stocks = stocks.filter(quantity__lte=10, quantity__gt=0)
    elif status == 'out':
        stocks = stocks.filter(quantity=0)
    
    # Pagination
    paginator = Paginator(stocks, 15)
    page = request.GET.get('page', 1)
    stocks = paginator.get_page(page)
    
    # Categories for filter dropdown
    categories = Category.objects.all()
    
    context = {
        'stocks': stocks,
        'categories': categories,
        'search_query': search_query,
        'selected_category': category_id,
        'selected_status': status,
    }
    
    return render(request, 'inventory/stock_list.html', context)


@login_required
def stock_add(request):
    """Add new stock item."""
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        sku = request.POST.get('sku', '').strip() or None
        category_id = request.POST.get('category') or None
        supplier_id = request.POST.get('supplier') or None
        description = request.POST.get('description', '').strip()
        quantity = int(request.POST.get('quantity', 0))
        unit = request.POST.get('unit', 'pcs')
        unit_price = float(request.POST.get('unit_price', 0))
        reorder_level = int(request.POST.get('reorder_level', 10))
        
        if not name:
            messages.error(request, 'Stock name is required.')
        else:
            stock = Stock.objects.create(
                name=name,
                sku=sku,
                category_id=category_id,
                supplier_id=supplier_id,
                description=description,
                quantity=quantity,
                unit=unit,
                unit_price=unit_price,
                reorder_level=reorder_level,
            )
            
            # Create initial stock history
            if quantity > 0:
                StockHistory.objects.create(
                    stock=stock,
                    direction='IN',
                    quantity=quantity,
                    previous_quantity=0,
                    new_quantity=quantity,
                    note='Initial stock',
                    created_by=request.user,
                )
            
            messages.success(request, f'Stock item "{name}" added successfully!')
            return redirect('stock_list')
    
    categories = Category.objects.all()
    suppliers = Supplier.objects.filter(is_active=True)
    
    context = {
        'categories': categories,
        'suppliers': suppliers,
    }
    
    return render(request, 'inventory/stock_form.html', context)


@login_required
def stock_edit(request, pk):
    """Edit existing stock item."""
    stock = get_object_or_404(Stock, pk=pk)
    
    if request.method == 'POST':
        stock.name = request.POST.get('name', '').strip()
        stock.sku = request.POST.get('sku', '').strip() or None
        stock.category_id = request.POST.get('category') or None
        stock.supplier_id = request.POST.get('supplier') or None
        stock.description = request.POST.get('description', '').strip()
        stock.unit = request.POST.get('unit', 'pcs')
        stock.unit_price = float(request.POST.get('unit_price', 0))
        stock.reorder_level = int(request.POST.get('reorder_level', 10))
        
        if not stock.name:
            messages.error(request, 'Stock name is required.')
        else:
            stock.save()
            messages.success(request, f'Stock item "{stock.name}" updated successfully!')
            return redirect('stock_list')
    
    categories = Category.objects.all()
    suppliers = Supplier.objects.filter(is_active=True)
    
    context = {
        'stock': stock,
        'categories': categories,
        'suppliers': suppliers,
        'edit_mode': True,
    }
    
    return render(request, 'inventory/stock_form.html', context)


@login_required
def stock_delete(request, pk):
    """Delete stock item."""
    stock = get_object_or_404(Stock, pk=pk)
    
    if request.method == 'POST':
        name = stock.name
        stock.delete()
        messages.success(request, f'Stock item "{name}" deleted successfully!')
        return redirect('stock_list')
    
    return render(request, 'inventory/stock_confirm_delete.html', {'stock': stock})


@login_required
def stock_detail(request, pk):
    """View stock item details with history."""
    stock = get_object_or_404(Stock, pk=pk)
    history = stock.history.select_related('created_by').order_by('-created_at')[:20]
    
    context = {
        'stock': stock,
        'history': history,
    }
    
    return render(request, 'inventory/stock_detail.html', context)


@login_required
def stock_adjust(request, pk):
    """Adjust stock quantity (manual stock in/out)."""
    stock = get_object_or_404(Stock, pk=pk)
    
    if request.method == 'POST':
        direction = request.POST.get('direction', 'IN')
        quantity = int(request.POST.get('quantity', 0))
        note = request.POST.get('note', '').strip()
        
        if quantity <= 0:
            messages.error(request, 'Quantity must be greater than 0.')
        elif direction == 'OUT' and quantity > stock.quantity:
            messages.error(request, 'Cannot remove more than available stock.')
        else:
            previous_quantity = stock.quantity
            
            if direction == 'IN':
                stock.quantity += quantity
            else:
                stock.quantity -= quantity
            
            stock.save()
            
            # Create history record
            StockHistory.objects.create(
                stock=stock,
                direction=direction,
                quantity=quantity,
                previous_quantity=previous_quantity,
                new_quantity=stock.quantity,
                note=note or f'Manual stock {direction.lower()}',
                created_by=request.user,
            )
            
            messages.success(request, f'Stock adjusted successfully! New quantity: {stock.quantity}')
            return redirect('stock_detail', pk=pk)
    
    return render(request, 'inventory/stock_adjust.html', {'stock': stock})


# =============================================================================
# CATEGORY VIEWS
# =============================================================================

@login_required
def category_list(request):
    """List all categories."""
    categories = Category.objects.annotate_stock_count()
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        categories = categories.filter(name__icontains=search_query)
    
    context = {
        'categories': categories,
        'search_query': search_query,
    }
    
    return render(request, 'inventory/category_list.html', context)


@login_required
def category_add(request):
    """Add new category."""
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        description = request.POST.get('description', '').strip()
        
        if not name:
            messages.error(request, 'Category name is required.')
        elif Category.objects.filter(name__iexact=name).exists():
            messages.error(request, 'Category with this name already exists.')
        else:
            Category.objects.create(name=name, description=description)
            messages.success(request, f'Category "{name}" added successfully!')
            return redirect('category_list')
    
    return render(request, 'inventory/category_form.html')


@login_required
def category_edit(request, pk):
    """Edit existing category."""
    category = get_object_or_404(Category, pk=pk)
    
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        description = request.POST.get('description', '').strip()
        
        if not name:
            messages.error(request, 'Category name is required.')
        elif Category.objects.filter(name__iexact=name).exclude(pk=pk).exists():
            messages.error(request, 'Category with this name already exists.')
        else:
            category.name = name
            category.description = description
            category.save()
            messages.success(request, f'Category "{name}" updated successfully!')
            return redirect('category_list')
    
    context = {
        'category': category,
        'edit_mode': True,
    }
    
    return render(request, 'inventory/category_form.html', context)


@login_required
def category_delete(request, pk):
    """Delete category."""
    category = get_object_or_404(Category, pk=pk)
    
    if request.method == 'POST':
        name = category.name
        category.delete()
        messages.success(request, f'Category "{name}" deleted successfully!')
        return redirect('category_list')
    
    return render(request, 'inventory/category_confirm_delete.html', {'category': category})


# =============================================================================
# SUPPLIER VIEWS
# =============================================================================

@login_required
def supplier_list(request):
    """List all suppliers."""
    suppliers = Supplier.objects.all()
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        suppliers = suppliers.filter(
            Q(name__icontains=search_query) |
            Q(contact_person__icontains=search_query) |
            Q(email__icontains=search_query)
        )
    
    # Filter by status
    status = request.GET.get('status', '')
    if status == 'active':
        suppliers = suppliers.filter(is_active=True)
    elif status == 'inactive':
        suppliers = suppliers.filter(is_active=False)
    
    context = {
        'suppliers': suppliers,
        'search_query': search_query,
        'selected_status': status,
    }
    
    return render(request, 'inventory/supplier_list.html', context)


@login_required
def supplier_add(request):
    """Add new supplier."""
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        contact_person = request.POST.get('contact_person', '').strip()
        email = request.POST.get('email', '').strip()
        phone = request.POST.get('phone', '').strip()
        address = request.POST.get('address', '').strip()
        
        if not name:
            messages.error(request, 'Supplier name is required.')
        else:
            Supplier.objects.create(
                name=name,
                contact_person=contact_person,
                email=email,
                phone=phone,
                address=address,
            )
            messages.success(request, f'Supplier "{name}" added successfully!')
            return redirect('supplier_list')
    
    return render(request, 'inventory/supplier_form.html')


@login_required
def supplier_edit(request, pk):
    """Edit existing supplier."""
    supplier = get_object_or_404(Supplier, pk=pk)
    
    if request.method == 'POST':
        supplier.name = request.POST.get('name', '').strip()
        supplier.contact_person = request.POST.get('contact_person', '').strip()
        supplier.email = request.POST.get('email', '').strip()
        supplier.phone = request.POST.get('phone', '').strip()
        supplier.address = request.POST.get('address', '').strip()
        supplier.is_active = request.POST.get('is_active') == 'on'
        
        if not supplier.name:
            messages.error(request, 'Supplier name is required.')
        else:
            supplier.save()
            messages.success(request, f'Supplier "{supplier.name}" updated successfully!')
            return redirect('supplier_list')
    
    context = {
        'supplier': supplier,
        'edit_mode': True,
    }
    
    return render(request, 'inventory/supplier_form.html', context)


@login_required
def supplier_delete(request, pk):
    """Delete supplier."""
    supplier = get_object_or_404(Supplier, pk=pk)
    
    if request.method == 'POST':
        name = supplier.name
        supplier.delete()
        messages.success(request, f'Supplier "{name}" deleted successfully!')
        return redirect('supplier_list')
    
    return render(request, 'inventory/supplier_confirm_delete.html', {'supplier': supplier})


# =============================================================================
# STOCK HISTORY VIEW
# =============================================================================

@login_required
def stock_history(request):
    """View all stock history."""
    history = StockHistory.objects.select_related('stock', 'created_by').all()
    
    # Filter by direction
    direction = request.GET.get('direction', '')
    if direction:
        history = history.filter(direction=direction)
    
    # Filter by stock item
    stock_id = request.GET.get('stock', '')
    if stock_id:
        history = history.filter(stock_id=stock_id)
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        history = history.filter(
            Q(stock__name__icontains=search_query) |
            Q(note__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(history, 20)
    page = request.GET.get('page', 1)
    history = paginator.get_page(page)
    
    # Stock items for filter dropdown
    stocks = Stock.objects.all()
    
    context = {
        'history': history,
        'stocks': stocks,
        'search_query': search_query,
        'selected_direction': direction,
        'selected_stock': stock_id,
    }
    
    return render(request, 'inventory/stock_history.html', context)
