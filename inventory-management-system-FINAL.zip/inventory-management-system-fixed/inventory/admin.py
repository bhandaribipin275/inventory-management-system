from django.contrib import admin
from .models import Category, Supplier, Stock, StockHistory


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'created_at']
    search_fields = ['name', 'description']


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ['name', 'contact_person', 'email', 'phone', 'is_active']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'contact_person', 'email']


@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ['name', 'sku', 'category', 'quantity', 'unit', 'unit_price', 'is_active']
    list_filter = ['category', 'supplier', 'is_active']
    search_fields = ['name', 'sku', 'description']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(StockHistory)
class StockHistoryAdmin(admin.ModelAdmin):
    list_display = ['stock', 'direction', 'quantity', 'previous_quantity', 'new_quantity', 'created_by', 'created_at']
    list_filter = ['direction', 'created_at']
    search_fields = ['stock__name', 'note']
    readonly_fields = ['stock', 'direction', 'quantity', 'previous_quantity', 'new_quantity', 'created_by', 'created_at']
