from django.contrib import admin
from .models import Purchase, PurchaseItem, Sale, SaleItem


class PurchaseItemInline(admin.TabularInline):
    model = PurchaseItem
    extra = 1
    readonly_fields = ['total_price']


@admin.register(Purchase)
class PurchaseAdmin(admin.ModelAdmin):
    list_display = ['transaction_number', 'supplier', 'date', 'total_amount', 'status', 'created_by']
    list_filter = ['status', 'date', 'supplier']
    search_fields = ['transaction_number', 'supplier__name']
    readonly_fields = ['transaction_number', 'total_amount', 'created_at', 'updated_at']
    inlines = [PurchaseItemInline]


class SaleItemInline(admin.TabularInline):
    model = SaleItem
    extra = 1
    readonly_fields = ['total_price']


@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ['transaction_number', 'customer_name', 'date', 'total_amount', 'discount', 'final_amount', 'status', 'created_by']
    list_filter = ['status', 'date']
    search_fields = ['transaction_number', 'customer_name', 'customer_phone']
    readonly_fields = ['transaction_number', 'total_amount', 'final_amount', 'created_at', 'updated_at']
    inlines = [SaleItemInline]
