from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Sum
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.utils import timezone

from .models import Purchase, PurchaseItem, Sale, SaleItem
from inventory.models import Stock, Supplier, StockHistory


# =============================================================================
# PURCHASE VIEWS
# =============================================================================

@login_required
def purchase_list(request):
    """List all purchases."""
    purchases = Purchase.objects.select_related('supplier', 'created_by').all()
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        purchases = purchases.filter(
            Q(transaction_number__icontains=search_query) |
            Q(supplier__name__icontains=search_query)
        )
    
    # Filter by status
    status = request.GET.get('status', '')
    if status:
        purchases = purchases.filter(status=status)
    
    # Pagination
    paginator = Paginator(purchases, 15)
    page = request.GET.get('page', 1)
    purchases = paginator.get_page(page)
    
    context = {
        'purchases': purchases,
        'search_query': search_query,
        'selected_status': status,
    }
    
    return render(request, 'transactions/purchase_list.html', context)


@login_required
def purchase_add(request):
    """Create new purchase."""
    if request.method == 'POST':
        supplier_id = request.POST.get('supplier') or None
        date = request.POST.get('date') or timezone.now().date()
        notes = request.POST.get('notes', '').strip()
        
        # Create purchase
        purchase = Purchase.objects.create(
            supplier_id=supplier_id,
            date=date,
            notes=notes,
            status='completed',
            created_by=request.user,
        )
        
        # Process items
        stock_ids = request.POST.getlist('stock_id[]')
        quantities = request.POST.getlist('quantity[]')
        unit_prices = request.POST.getlist('unit_price[]')
        
        total_amount = 0
        
        for i in range(len(stock_ids)):
            if stock_ids[i] and quantities[i]:
                stock = Stock.objects.get(pk=stock_ids[i])
                quantity = int(quantities[i])
                unit_price = float(unit_prices[i]) if unit_prices[i] else stock.unit_price
                
                # Create purchase item
                PurchaseItem.objects.create(
                    purchase=purchase,
                    stock=stock,
                    quantity=quantity,
                    unit_price=unit_price,
                )
                
                # Update stock quantity
                previous_quantity = stock.quantity
                stock.quantity += quantity
                stock.save()
                
                # Create stock history
                StockHistory.objects.create(
                    stock=stock,
                    direction='IN',
                    quantity=quantity,
                    previous_quantity=previous_quantity,
                    new_quantity=stock.quantity,
                    note=f'Purchase: {purchase.transaction_number}',
                    created_by=request.user,
                )
                
                total_amount += quantity * unit_price
        
        purchase.total_amount = total_amount
        purchase.save()
        
        messages.success(request, f'Purchase {purchase.transaction_number} created successfully!')
        return redirect('purchase_list')
    
    suppliers = Supplier.objects.filter(is_active=True)
    stocks = Stock.objects.filter(is_active=True)
    
    context = {
        'suppliers': suppliers,
        'stocks': stocks,
        'today': timezone.now().date(),
    }
    
    return render(request, 'transactions/purchase_form.html', context)


@login_required
def purchase_detail(request, pk):
    """View purchase details."""
    purchase = get_object_or_404(Purchase, pk=pk)
    items = purchase.items.select_related('stock')
    
    context = {
        'purchase': purchase,
        'items': items,
    }
    
    return render(request, 'transactions/purchase_detail.html', context)


@login_required
def purchase_delete(request, pk):
    """Delete/cancel purchase."""
    purchase = get_object_or_404(Purchase, pk=pk)
    
    if request.method == 'POST':
        # Reverse stock changes
        for item in purchase.items.all():
            stock = item.stock
            previous_quantity = stock.quantity
            stock.quantity -= item.quantity
            if stock.quantity < 0:
                stock.quantity = 0
            stock.save()
            
            # Create reversal history
            StockHistory.objects.create(
                stock=stock,
                direction='OUT',
                quantity=item.quantity,
                previous_quantity=previous_quantity,
                new_quantity=stock.quantity,
                note=f'Purchase cancelled: {purchase.transaction_number}',
                created_by=request.user,
            )
        
        transaction_number = purchase.transaction_number
        purchase.delete()
        messages.success(request, f'Purchase {transaction_number} deleted successfully!')
        return redirect('purchase_list')
    
    return render(request, 'transactions/purchase_confirm_delete.html', {'purchase': purchase})


# =============================================================================
# SALE VIEWS
# =============================================================================

@login_required
def sale_list(request):
    """List all sales."""
    sales = Sale.objects.select_related('created_by').all()
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        sales = sales.filter(
            Q(transaction_number__icontains=search_query) |
            Q(customer_name__icontains=search_query)
        )
    
    # Filter by status
    status = request.GET.get('status', '')
    if status:
        sales = sales.filter(status=status)
    
    # Pagination
    paginator = Paginator(sales, 15)
    page = request.GET.get('page', 1)
    sales = paginator.get_page(page)
    
    context = {
        'sales': sales,
        'search_query': search_query,
        'selected_status': status,
    }
    
    return render(request, 'transactions/sale_list.html', context)


@login_required
def sale_add(request):
    """Create new sale."""
    if request.method == 'POST':
        customer_name = request.POST.get('customer_name', '').strip()
        customer_phone = request.POST.get('customer_phone', '').strip()
        date = request.POST.get('date') or timezone.now().date()
        notes = request.POST.get('notes', '').strip()
        discount = float(request.POST.get('discount', 0))
        
        # Create sale
        sale = Sale.objects.create(
            customer_name=customer_name,
            customer_phone=customer_phone,
            date=date,
            notes=notes,
            discount=discount,
            status='completed',
            created_by=request.user,
        )
        
        # Process items
        stock_ids = request.POST.getlist('stock_id[]')
        quantities = request.POST.getlist('quantity[]')
        unit_prices = request.POST.getlist('unit_price[]')
        
        total_amount = 0
        errors = []
        
        for i in range(len(stock_ids)):
            if stock_ids[i] and quantities[i]:
                stock = Stock.objects.get(pk=stock_ids[i])
                quantity = int(quantities[i])
                unit_price = float(unit_prices[i]) if unit_prices[i] else stock.unit_price
                
                # Check stock availability
                if quantity > stock.quantity:
                    errors.append(f'Insufficient stock for {stock.name}. Available: {stock.quantity}')
                    continue
                
                # Create sale item
                SaleItem.objects.create(
                    sale=sale,
                    stock=stock,
                    quantity=quantity,
                    unit_price=unit_price,
                )
                
                # Update stock quantity
                previous_quantity = stock.quantity
                stock.quantity -= quantity
                stock.save()
                
                # Create stock history
                StockHistory.objects.create(
                    stock=stock,
                    direction='OUT',
                    quantity=quantity,
                    previous_quantity=previous_quantity,
                    new_quantity=stock.quantity,
                    note=f'Sale: {sale.transaction_number}',
                    created_by=request.user,
                )
                
                total_amount += quantity * unit_price
        
        if errors:
            for error in errors:
                messages.warning(request, error)
        
        sale.total_amount = total_amount
        sale.final_amount = total_amount - discount
        sale.save()
        
        messages.success(request, f'Sale {sale.transaction_number} created successfully!')
        return redirect('sale_list')
    
    stocks = Stock.objects.filter(is_active=True, quantity__gt=0)
    
    context = {
        'stocks': stocks,
        'today': timezone.now().date(),
    }
    
    return render(request, 'transactions/sale_form.html', context)


@login_required
def sale_detail(request, pk):
    """View sale details (Bill/Invoice)."""
    sale = get_object_or_404(Sale, pk=pk)
    items = sale.items.select_related('stock')
    
    context = {
        'sale': sale,
        'items': items,
    }
    
    return render(request, 'transactions/sale_detail.html', context)


@login_required
def sale_delete(request, pk):
    """Delete/cancel sale."""
    sale = get_object_or_404(Sale, pk=pk)
    
    if request.method == 'POST':
        # Reverse stock changes
        for item in sale.items.all():
            stock = item.stock
            previous_quantity = stock.quantity
            stock.quantity += item.quantity
            stock.save()
            
            # Create reversal history
            StockHistory.objects.create(
                stock=stock,
                direction='IN',
                quantity=item.quantity,
                previous_quantity=previous_quantity,
                new_quantity=stock.quantity,
                note=f'Sale cancelled: {sale.transaction_number}',
                created_by=request.user,
            )
        
        transaction_number = sale.transaction_number
        sale.delete()
        messages.success(request, f'Sale {transaction_number} deleted successfully!')
        return redirect('sale_list')
    
    return render(request, 'transactions/sale_confirm_delete.html', {'sale': sale})


# =============================================================================
# API ENDPOINTS
# =============================================================================

@login_required
def get_stock_info(request, pk):
    """Get stock item info for AJAX calls."""
    try:
        stock = Stock.objects.get(pk=pk)
        return JsonResponse({
            'id': stock.id,
            'name': stock.name,
            'sku': stock.sku,
            'quantity': stock.quantity,
            'unit': stock.unit,
            'unit_price': float(stock.unit_price),
        })
    except Stock.DoesNotExist:
        return JsonResponse({'error': 'Stock not found'}, status=404)
