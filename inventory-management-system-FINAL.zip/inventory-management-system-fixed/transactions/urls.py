from django.urls import path
from . import views

urlpatterns = [
    # Purchase URLs
    path('purchases/', views.purchase_list, name='purchase_list'),
    path('purchases/add/', views.purchase_add, name='purchase_add'),
    path('purchases/<int:pk>/', views.purchase_detail, name='purchase_detail'),
    path('purchases/<int:pk>/delete/', views.purchase_delete, name='purchase_delete'),
    
    # Sale URLs
    path('sales/', views.sale_list, name='sale_list'),
    path('sales/add/', views.sale_add, name='sale_add'),
    path('sales/<int:pk>/', views.sale_detail, name='sale_detail'),
    path('sales/<int:pk>/delete/', views.sale_delete, name='sale_delete'),
    
    # API endpoints
    path('api/stock/<int:pk>/', views.get_stock_info, name='get_stock_info'),
]
